---
name: bijan-design-principles
description: Bijan's design principles (手応え), the governing guide for design work. Use before designing, building or reviewing any UI, UX, interaction, visual or audiovisual treatment, product logic, game, learning experience or other interactive or creative experience, and whenever Bijan's design preferences or 手応え come up.
---

# Bijan's design principles

1. Before the first design decision, read `bijan-design-principles.html` in this skill's folder in full (the text; the CSS is presentation). It is the complete guide; its reasoning governs the work alongside the project's own brief.
2. Work by the terms below throughout.

## Working terms
- **手応え** in every action: considered, satisfying interaction with an immediate functional response. Scale the care to how much the action matters.
- Aim for purposeful immersion and fluent mastery.
- Resolve routine, reversible choices yourself.
- Bring consequential uncertainty to Bijan with options and a recommendation.
- Build a representative playable sequence early, before polishing parts.
- Keep administration to what the work needs.
- Report in two columns: what was technically verified, and what Bijan has experienced and accepted.

## Tooling
- Run design retros inline: compare the outcome against the intent. (The /retro skill reviews the agent's setup, a different question.)
- Reserve /wayfinder for multi-session work.
